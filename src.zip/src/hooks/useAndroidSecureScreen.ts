import { useEffect } from 'react';
import { Platform } from 'react-native';
import { useIsFocused } from '@react-navigation/native';
import RNScreenshotPrevent from 'react-native-screenshot-prevent';

function setSecureEnabled(value: boolean) {
  if (RNScreenshotPrevent?.enabled) {
    RNScreenshotPrevent.enabled(value);
    return;
  }

  if (value && RNScreenshotPrevent?.enableSecureView) {
    RNScreenshotPrevent.enableSecureView();
    return;
  }

  if (!value && RNScreenshotPrevent?.disableSecureView) {
    RNScreenshotPrevent.disableSecureView();
  }
}

export function useAndroidSecureScreen(isActive: boolean) {
  const isFocused = useIsFocused();

  useEffect(() => {
    if (Platform.OS !== 'android') {
      return;
    }

    const shouldBeSecure = isFocused && isActive;

    setSecureEnabled(shouldBeSecure);

    return () => {
      setSecureEnabled(false);
    };
  }, [isFocused, isActive]);
}
