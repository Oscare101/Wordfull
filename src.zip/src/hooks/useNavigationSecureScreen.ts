import { useEffect } from 'react';
import { Platform } from 'react-native';
import { NavigationContainerRef } from '@react-navigation/native';
import RNScreenshotPrevent from 'react-native-screenshot-prevent';

const SECURE_SCREENS: any = ['GameScreen'];

function enableSecure() {
  if (RNScreenshotPrevent?.enabled) {
    console.log(1);

    RNScreenshotPrevent.enabled(true);
  } else if (RNScreenshotPrevent?.enableSecureView) {
    console.log(2);

    RNScreenshotPrevent.enableSecureView();
  }
}

function disableSecure() {
  if (RNScreenshotPrevent?.enabled) {
    console.log(3);

    RNScreenshotPrevent.enabled(false);
  } else if (RNScreenshotPrevent?.disableSecureView) {
    console.log(4);

    RNScreenshotPrevent.disableSecureView();
  }
}

export function useNavigationSecureScreen(
  navigationRef: React.RefObject<NavigationContainerRef<any>>,
) {
  useEffect(() => {
    if (Platform.OS !== 'android') return;

    const unsubscribe = navigationRef.current?.addListener('state', () => {
      const route = navigationRef.current?.getCurrentRoute();
      const routeName = route?.name;
      console.log(routeName);

      if (SECURE_SCREENS.includes(routeName)) {
        enableSecure();
      } else {
        disableSecure();
      }
    });

    return () => {
      unsubscribe?.();
      disableSecure();
    };
  }, []);
}
