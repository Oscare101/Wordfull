import { useMemo } from 'react';
import { useHistory } from '../context/HistoryContext';

const {
  wordsLearnedToday,

  wordsLearnedWeek,
  wordsLearnedWeekDailyAverage,

  wordsLearnedMonth,
  wordsLearnedMonthDailyAverage,

  wordsLearnedYear,
  wordsLearnedYearDailyAverage,

  wordsLearnedTotal,
  wordsLearnedDailyAverage,
} = usePeriodStats();

function getStartOfTodayTimestamp(): number {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return now.getTime();
}

function getStartOfDaysAgo(days: number): number {
  const startOfToday = getStartOfTodayTimestamp();
  return startOfToday - days * 24 * 60 * 60 * 1000;
}

function getDayKey(timestamp: number): string {
  const date = new Date(timestamp);
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');

  return `${year}-${month}-${day}`;
}

interface PeriodStats {
  wordsLearnedTotal: number;
  wordsLearnedDailyAverage: number;
}

export function usePeriodStats() {
  const { history } = useHistory();

  return useMemo(() => {
    const now = Date.now();

    const ranges = {
      today: getStartOfTodayTimestamp(),
      week: getStartOfDaysAgo(6),
      month: getStartOfDaysAgo(29),
      year: getStartOfDaysAgo(364),
    };

    let wordsLearnedToday = 0;
    let wordsLearnedWeek = 0;
    let wordsLearnedMonth = 0;
    let wordsLearnedYear = 0;
    let wordsLearnedTotal = 0;

    const activeDaysWeek = new Set<string>();
    const activeDaysMonth = new Set<string>();
    const activeDaysYear = new Set<string>();
    const activeDaysTotal = new Set<string>();

    for (const item of history) {
      const ts = item.timestamp;
      const correctWords = item.correctWords;
      const dayKey = getDayKey(ts);

      wordsLearnedTotal += correctWords;
      activeDaysTotal.add(dayKey);

      if (ts >= ranges.year && ts <= now) {
        wordsLearnedYear += correctWords;
        activeDaysYear.add(dayKey);

        if (ts >= ranges.month) {
          wordsLearnedMonth += correctWords;
          activeDaysMonth.add(dayKey);

          if (ts >= ranges.week) {
            wordsLearnedWeek += correctWords;
            activeDaysWeek.add(dayKey);

            if (ts >= ranges.today) {
              wordsLearnedToday += correctWords;
            }
          }
        }
      }
    }

    const buildAverage = (total: number, activeDaysCount: number): number => {
      if (activeDaysCount === 0) {
        return 0;
      }

      return total / activeDaysCount;
    };

    return {
      wordsLearnedToday,

      wordsLearnedWeek,
      wordsLearnedWeekDailyAverage: buildAverage(
        wordsLearnedWeek,
        activeDaysWeek.size,
      ),

      wordsLearnedMonth,
      wordsLearnedMonthDailyAverage: buildAverage(
        wordsLearnedMonth,
        activeDaysMonth.size,
      ),

      wordsLearnedYear,
      wordsLearnedYearDailyAverage: buildAverage(
        wordsLearnedYear,
        activeDaysYear.size,
      ),

      wordsLearnedTotal,
      wordsLearnedDailyAverage: buildAverage(
        wordsLearnedTotal,
        activeDaysTotal.size,
      ),
    };
  }, [history]);
}
