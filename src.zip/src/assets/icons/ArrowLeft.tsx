export default function ArrowLeft(color: string) {
  return `<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M244 400L100 256L244 112M120 256H412" stroke="${color}" stroke-width="48" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

`;
}
