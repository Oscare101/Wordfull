export default function Info(color: string) {
  return `
<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M248 64C146.39 64 64 146.39 64 248C64 349.61 146.39 432 248 432C349.61 432 432 349.61 432 248C432 146.39 349.61 64 248 64Z" stroke=${color} stroke-width="32" stroke-miterlimit="10"/>
<path d="M220 220H252V336" stroke=${color} stroke-width="32" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M208 340H296" stroke=${color} stroke-width="32" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M248 130C242.858 130 237.831 131.525 233.555 134.382C229.28 137.239 225.947 141.299 223.979 146.05C222.011 150.801 221.496 156.029 222.5 161.072C223.503 166.116 225.979 170.749 229.615 174.385C233.251 178.021 237.884 180.497 242.928 181.5C247.971 182.504 253.199 181.989 257.95 180.021C262.701 178.053 266.761 174.721 269.618 170.445C272.475 166.169 274 161.142 274 156C274 149.104 271.261 142.491 266.385 137.615C261.509 132.739 254.896 130 248 130Z" fill=${color}/>
</svg>

`;
}
