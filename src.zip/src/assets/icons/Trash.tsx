export default function Trash(color: string) {
  return `
<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M112 112L132 432C132.95 450.49 146.4 464 164 464H348C365.67 464 378.87 450.49 380 432L400 112" stroke="${color}" stroke-width="32" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M80 112H432H80Z" fill="${color}"/>
<path d="M80 112H432" stroke="${color}" stroke-width="32" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M192 112V72.0001C191.991 68.8458 192.605 65.7208 193.808 62.8048C195.011 59.8888 196.778 57.2394 199.009 55.0089C201.239 52.7785 203.889 51.011 206.805 49.8082C209.721 48.6053 212.846 47.9909 216 48.0001H296C299.154 47.9909 302.279 48.6053 305.195 49.8082C308.111 51.011 310.761 52.7785 312.991 55.0089C315.222 57.2394 316.989 59.8888 318.192 62.8048C319.395 65.7208 320.009 68.8458 320 72.0001V112M256 176V400M184 176L192 400M328 176L320 400" stroke="${color}" stroke-width="32" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

`;
}
