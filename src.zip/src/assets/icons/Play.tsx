export default function Play(color: string) {
  return `
<svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.5625 6.5039V23.4961C6.5625 24.518 7.55859 25.1672 8.37891 24.6773L22.9043 15.9838C23.6145 15.559 23.6145 14.441 22.9043 14.0162L8.37891 5.32265C7.55859 4.8328 6.5625 5.48202 6.5625 6.5039Z" stroke="${color}" stroke-width="2.5" stroke-miterlimit="10"/>
</svg>


`;
}
