import { StyleSheet, Text, View } from 'react-native';
import React from 'react';
import {
  History,
  Language,
  Statistics,
} from '../../constants/interfaces/interface';
import { ThemeType } from '../../constants/themes/themeType';
import text from '../../constants/languages/text';
import colors from '../../constants/themes/colors';
import HistoryActivityChart from './HistoryActivityChart';
import { getWordsLearnedToday } from '../../utils/getWordsLearnedToday';
import { usePeriodStats } from '../../hooks/usePeriodStats';

export default function MonthHistoryBlock({
  history,
  statistics,
  language,
  theme,
  type,
}: {
  history: History[];
  statistics: Statistics | null;
  language: Language;
  theme: ThemeType;
  type: 'month' | 'week';
}) {
  const {
    wordsLearnedToday,
    wordsLearnedWeek,
    wordsLearnedMonth,
    wordsLearnedYear,
  } = usePeriodStats();

  const wordsAmount = type === 'month' ? wordsLearnedMonth : wordsLearnedWeek;

  const wordsTitle =
    wordsAmount % 10 === 1
      ? text[language].Word
      : wordsAmount && [2, 3, 4].includes(wordsAmount % 10)
      ? text[language].Words23
      : text[language].Words;

  return (
    <View style={[styles.container, { borderColor: colors[theme].border }]}>
      <Text style={{ fontSize: 14, color: colors[theme].main }}>
        {text[language].TotalWordsMemorized}{' '}
        {type === 'month'
          ? text[language].inPast30Days
          : text[language].inPastWeek}
      </Text>
      <Text
        style={{ fontSize: 16, color: colors[theme].main, fontWeight: 'bold' }}
      >
        {wordsAmount} {wordsTitle}
      </Text>
      <HistoryActivityChart
        history={history}
        days={type === 'month' ? 30 : 7}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    borderWidth: 1,
    borderRadius: 8,
    padding: 8,
  },
});
