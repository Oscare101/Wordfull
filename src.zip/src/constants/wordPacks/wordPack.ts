import {
  DEFAULT_SYSTEM_WORD_PACK_KEYS,
  Language,
  SystemWordPackKey,
  WordPack,
} from '../interfaces/interface';
import { common_noun_en_100 } from './common-nouns-en-100';
import { common_noun_en_1000 } from './common-nouns-en-1000';
import { common_noun_uk_100 } from './common-nouns-uk-100';
import { common_noun_uk_1000 } from './common-nouns-uk-1000';

type SystemWordPacksByLanguage = Record<
  Language,
  Partial<Record<SystemWordPackKey, WordPack>>
>;

export const SYSTEM_WORD_PACKS: SystemWordPacksByLanguage = {
  en: {
    simple_nouns: common_noun_en_100,
    complex_nouns: common_noun_en_1000,
  },
  uk: {
    simple_nouns: common_noun_uk_100,
    complex_nouns: common_noun_uk_1000,
  },
};

export function getAllSystemWordPacks(): WordPack[] {
  return Object.values(SYSTEM_WORD_PACKS).flatMap(languagePacks =>
    Object.values(languagePacks).filter(Boolean),
  ) as WordPack[];
}

export function getSystemWordPackByKey(
  language: Language,
  key: SystemWordPackKey,
): WordPack | undefined {
  return SYSTEM_WORD_PACKS[language]?.[key];
}

export function getSystemWordPacksByLanguage(language: Language): WordPack[] {
  return Object.values(SYSTEM_WORD_PACKS[language]).filter(
    Boolean,
  ) as WordPack[];
}

export function getSystemWordPacksByKeys(
  language: Language,
  keys: SystemWordPackKey[],
): WordPack[] {
  return keys
    .map(key => getSystemWordPackByKey(language, key))
    .filter(Boolean) as WordPack[];
}

export function getMergedSystemWordPackByLanguageAndKeys(
  language: Language,
  keys: SystemWordPackKey[],
): WordPack {
  const packs = getSystemWordPacksByKeys(language, keys);

  const safePacks =
    packs.length > 0
      ? packs
      : getSystemWordPacksByKeys(language, DEFAULT_SYSTEM_WORD_PACK_KEYS);

  const uniqueWords = Array.from(
    new Set(safePacks.flatMap(pack => pack.words)),
  );

  const mergedName =
    safePacks.length === 1
      ? safePacks[0].name
      : safePacks.map(pack => pack.name).join(' + ');

  const mergedId = `system-${language}-${safePacks
    .map(pack => pack.key ?? pack.id)
    .join('+')}`;

  return {
    id: mergedId,
    key: undefined,
    name: mergedName,
    isSystem: true,
    language,
    words: uniqueWords,
  };
}
