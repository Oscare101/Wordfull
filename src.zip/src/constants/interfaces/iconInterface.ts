export type IconName = 'chevronLeft';
