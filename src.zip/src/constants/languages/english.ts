import { GameMode } from './../interfaces/interface';
import { TextType } from './textType';

const english = {
  Settings: 'Settings',
  Theme: 'Theme',
  Language: 'Language',
  Ukrainian: 'Українська',
  English: 'English',
  // language screen
  YourLanguage: 'Your language',
  OtherLanguages: 'Other languages',
  AfterChangingLanguageWarning:
    'After changing the language, the word pack will be changed to the new language. You still can change it to any language you want in the word pack settings.',
  YourTheme: 'Your theme',
  OtherThemes: 'Other themes',
  // game modes screen
  NewGame: 'New Game',
  Easy: 'Easy',
  Hard: 'Hard',
  Stamina: 'Stamina',
  EasyTitle: 'Easy Mode',
  HardTitle: 'Hard Mode',
  StaminaTitle: 'Stamina Mode',
  Start: 'Start',
  easyDescription:
    '• Limited number of words\n• You can go back to previous ones\n• Open list of all words',
  hardDescription:
    "• Limited number of words\n• You can't go back to previous cards\n• List of words is unavailable",
  staminaDescription:
    "• Unlimited number of words\n• You can't go back to previous cards\n• List of words is unavailable",
  gamePreambula:
    '• There will be cards with words on the screen\n• Switch between them and remember them in the correct order in the shortest time\n• After that, go to the check and enter all the words\n• Complete the attempt and check the result',
  startWhenReady: "Start when you're ready\nThe time will start immediately",
  NumberOfWordsForExercise: 'Number of words for exercise',
  wordsMaxWarning: 'Maximum number of words available #',
  CloseGameWarningTitle: 'Stop game',
  CloseGameWarning:
    'Are you sure you want to stop the game?\nThe attempt will be counted, and be saved to history as not finished',
  CancelGameWarningTitle: 'Cancel the game',
  CancelGameWarning:
    "Are you sure you want to cancel the game?\nYour progress won't be saved",
  Cancel: 'Cancel',
  Continue: 'Continue',
  goBack: 'Go back',
  Stop: 'Stop',
  Check: 'Check',
  IfYouReadyToCheck: "If you've learned all the words and are ready to check",
  list: 'list',
  backToCards: 'to cards',
  timeMemorizing: 'time for memorizing',
  sec: 'sec.',
  min: 'min.',
  hours: 'hours.',
  IfYouEnteredWords:
    "If you've entered all the words and are ready to finish the attempt",
  Finish: 'Finish',
  ConfirmWarningTitle: 'Finish attempt',
  ConfirmWarning: 'Finish the attempt, even with empty fields',
  correctWordsMemorized: 'correct words memorized',
  TotalWordsMemorized: 'Total words memorized',
  Words: 'Words',
  Words23: 'Words',
  Word: 'Word',
  Days: 'Days',
  Day: 'Day',
  PersonalBestResults: 'Personal Best results',
  WordsAmount: 'Words amount',
  Accuracy: 'Accuracy',
  inPastWeek: 'in Past week',
  inPastMonth: 'in Past month',
  inPastYear: 'in Past year',
  inPast30Days: 'in Past 30 days',
  GamesCompleted: 'Games completed',
  TimePlaying: 'Time playing',
  MondayShort: 'M',
  TuesdayShort: 'T',
  WednesdayShort: 'W',
  ThursdayShort: 'T',
  FridayShort: 'F',
  SaturdayShort: 'S',
  SundayShort: 'S',
  DailyAverage: 'Daily average',
  Today: 'Today',
  Yesterday: 'Yesterday',
  PastWeek: 'Past week',
  PastMonth: 'Past month',
  PastYear: 'Past year',
  AllTime: 'All time',
  inAllTime: 'in All time',
  UserData: 'User data',
  Export: 'Export',
  ExportDescription:
    'Exported data can be used as a back up or to transfer your progress to another device\nBy exporting data you dont lose your progress on this device, when you import data to the current device it will rewrite the previous data',
  Import: 'Import',
  ImportDescription:
    'Imported data will rewrite all your current progress\nAfter loading file you will be shown a window to confirm your choice with brief file data',
  DangerZone: 'Danger zone',
  WipeData: 'Wipe data',
  WipeDataDescription:
    'This will wipe all your data and allow you to start from scratch',
  Statistics: 'Statistics',
  quote1:
    '“Intellectual growth should commence at birth and cease only at death.”',
  quote1Author: 'Albert Einstein',
  Explanation:
    'The game consists of two stages:\n\n1. Memorization\n2. Check (write memorized words)\n\nDuring the memorization stage, you will be shown cards with words. You can switch between them and take as much time as you need to memorize them.\nWhen you feel ready to check, press the "Check" button.\n\nDuring the check stage, you need to enter all the words in the correct order. You can not see the list of all words or go back to cards after you switched to the check stage. When you finish entering words, press the "Finish" button to see your result.',
  GameModeExplanation:
    'In the Easy mode, you memorize a limited amount of words, you can go back to previous cards and see the list of all words during the memorizing stage.\n\nIn the Hard mode, you also memorize a limited amount of words, but you can not go back to previous cards or see the list of all words during the memorizing stage.\n\nIn the Stamina mode, you memorize an unlimited amount of words, without ability to go back to previous cards or see the list of all words during the memorizing stage. And in this mode you can stop memorizing at any point at any amount of words',
  PreGameEasyHardExplanation:
    "On this screen you can select how many words you want to memorize during the game. The more words you select, the harder it will be to memorize them, and all the words that you don't memorize will be counted as not memorized, so choose the amount of words that you think you can memorize to get the best result",
  PreGameStaminaExplanation:
    "In stamina mode there is no limit on how many words you can memorize, but the more words you try to look through, the harder it will be to memorize them all, and the words that you don't memorize will be counted as not memorized, so you can stop memorizing at any point to get the best result.\n\nAlso note that Word Pack that is used in the game is limited. Currently it only contains # unique words in it",
  YourInputs: 'Your inputs',
  StaminaLastWordWarning:
    'WOW! This is the last word in the Word Pack, please go to the check stage and write all the memorized words',
} satisfies Record<TextType, string>;

export default english;
